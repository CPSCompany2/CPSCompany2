<?php
$text = $_SERVER["REQUEST_URI"];
$string = str_replace('/', '', $text );
$class = ' class="active"';
?>
<div class="container">
       <div class="features-tab--nav">
                <ul>
                    <li<?php if($string == 'recharge_zone'){echo $class;}?>><a href="recharge_zone" class="btn btn-lg btn-custom">Mobile</a></li>
                    <li<?php if($string == 'dth'){echo $class;}?>><a href="dth" class="btn btn-lg btn-custom">DTH</a></li>
                    <li<?php if($string == 'data_card'){echo $class;}?>><a href="data_card" class="btn btn-lg btn-custom">Data Card</a></li>
                    <li<?php if($string == 'postpaid'){echo $class;}?>><a href="postpaid" class="btn btn-lg btn-custom">Post Paid</a></li>
                    <li<?php if($string == 'electricity'){echo $class;}?>><a href="electricity" class="btn btn-lg btn-custom">Electricity</a></li>
                    <li<?php if($string == 'gas'){echo $class;}?>><a href="gas" class="btn btn-lg btn-custom">Gas</a></li>
                    <li<?php if($string == 'insurance'){echo $class;}?>><a href="insurance" class="btn btn-lg btn-custom">insurance</a></li>
                    <li<?php if($string == 'money_transfer'){echo $class;}?>><a href="money_transfer" class="btn btn-lg btn-custom">Money Transfer</a></li>
                    
                </ul>
            </div>
           </div>