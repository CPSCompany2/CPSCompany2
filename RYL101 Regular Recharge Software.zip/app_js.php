  <!-- ==== jQuery Library ==== -->
    <script src="<?php echo base_url().'app_js/jquery-3.1.0.min.js';?>"></script>

    <!-- ==== jQuery UI ==== -->
    <script src="<?php echo base_url().'app_js/jquery-ui.min.js';?>"></script>
    
    <!-- ==== jQuery UI Touch Punch Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.ui.touch-punch.min.js';?>"></script>

    <!-- ==== Bootstrap ==== -->
    <script src="<?php echo base_url().'app_js/bootstrap.min.js';?>"></script>

    <!-- ==== FakeLoader Plugin ==== -->
    <script src="<?php echo base_url().'app_js/fakeLoader.min.js';?>"></script>

    <!-- ==== StickyJS Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.sticky.js';?>"></script>

    <!-- ==== Owl Carousel Plugin ==== -->
    <script src="<?php echo base_url().'app_js/owl.carousel.min.js';?>"></script>
    
    <!-- ==== jQuery Tubuler Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.tubular.1.0.js';?>"></script>
    
    <!-- ==== Magnific Popup Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.magnific-popup.min.js';?>"></script>

    <!-- ==== jQuery Validation Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.validate.min.js';?>"></script>

    <!-- ==== Animate Scroll Plugin ==== -->
    <script src="<?php echo base_url().'app_js/animatescroll.min.js';?>"></script>

    <!-- ==== jQuery Waypoints Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.waypoints.min.js';?>"></script>

    <!-- ==== jQuery CounterUp Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.counterup.min.js';?>"></script>
    
    <!-- ==== jQuery CountDown Plugin ==== -->
    <script src="<?php echo base_url().'app_js/jquery.countdown.min.js';?>"></script>
    
    <!-- ==== RetinaJS ==== -->
    <script src="<?php echo base_url().'app_js/retina.min.js';?>"></script>

    <!-- ==== Main JavaScript ==== -->
    <script src="<?php echo base_url().'app_js/main.js';?>"></script>